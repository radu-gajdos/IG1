class Iterator:
    def __init__(self, bag):
        self.bag = bag
        if self.valid():
            self.iter = 0

    def valid(self):
        if len(self.bag) == 0:
            raise IndexError
        return True

    def first(self):
        self.iter = 0

    def next(self):
        if self.valid():
            self.iter += 1

    def getCurrent(self):
        if self.valid():
            return self.bag[self.iter]
