from Bag import *


def main():
    bag = Bag()
    # BAG METHODS

    # ADD FUNCTION
    bag.add(1)
    bag.liste += [2, 3, 4, 5, 6]
    assert bag.liste == [1, 2, 3, 4, 5, 6]
    # REMOVE FUNCTION
    bag.remove(2)
    assert bag.liste == [1, 3, 4, 5, 6]
    # SEARCH FUNCTION
    assert bag.search(3) == True
    # SIZE FUNCTION
    assert bag.size() == 5
    # OCCURRENCES FUNCTION
    assert bag.nrOccurrences(3) == 1
    # ITERATOR FUNCTION
    iterator = bag.iterator()
    # ITERATOR METHODS
    assert iterator.iter == 0
    # VALID FUNCTION
    assert iterator.valid() == True
    # FIRST FUNCTION => SET ITERATOR ON 0
    iterator.first()
    assert iterator.iter == 0
    # NEXT FUNCTION => INCREMENT ITERATOR
    iterator.next()
    assert iterator.iter == 1
    # GET CURRENT FUNCTION
    assert iterator.getCurrent() == 3


main()
