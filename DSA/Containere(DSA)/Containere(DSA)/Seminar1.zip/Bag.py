from Iterator import *


class Bag:
    def __init__(self):
        self.liste = []

    def add(self, el):
        self.liste.append(el)

    def remove(self, el):
        if el in self.liste:
            self.liste.remove(el)
            return True
        return False

    def search(self, el):
        if el not in self.liste:
            return False
        return True

    def size(self):
        return len(self.liste)

    def nrOccurrences(self, el):
        return self.liste.count(el)

    def destroy(self):
        del self

    def iterator(self):
        iter = Iterator(self.liste)
        return iter
