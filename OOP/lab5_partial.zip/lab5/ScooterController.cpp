//
// Created by Paul on 5/10/2023.
//

#include "ScooterController.h"

namespace scooterController {
} // scooterController