from run import start
def main():
    start()
main()