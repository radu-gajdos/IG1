def init_res(l):
    res=""
    for i in range(0,l):
        res+='_'
    return res