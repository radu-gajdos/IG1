def citeste_fisier(file):
    f = open(file, 'w') 
    return f