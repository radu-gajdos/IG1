def r():
    f = open("C:\\Users\\Radu\\Desktop\\python\\sapt6\\trei\\r.txt", 'r')
    print(f.read())
def p():
    f = open("C:\\Users\\Radu\\Desktop\\python\\sapt6\\trei\\p.txt", 'r')
    print(f.read())
def s():
    f = open("C:\\Users\\Radu\\Desktop\\python\\sapt6\\trei\\s.txt", 'r')
    print(f.read())
    
def deseneaza(e):
    if e=='r':
        r()
    if e=='p':
        p()
    if e=='s':
        s()